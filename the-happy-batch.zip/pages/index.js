import Link from 'next/link'
import { PRODUCTS } from '../lib/products'

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <header className="max-w-6xl mx-auto mb-8">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-extrabold">The Happy Batch</h1>
          <nav>
            <Link href="/cart">Cart</Link>
          </nav>
        </div>
        <p className="mt-2 text-sm text-gray-600">Small-batch cookies baked with love. Free local pickup over $30.</p>
      </header>

      <main className="max-w-6xl mx-auto grid lg:grid-cols-3 gap-8">
        <section className="lg:col-span-2">
          <h2 className="text-2xl font-bold mb-4">Our Cookies</h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {PRODUCTS.map(p => (
              <article key={p.id} className="bg-white rounded-lg shadow p-4">
                <img src={p.image} className="w-full h-48 object-cover rounded-md" />
                <h3 className="mt-3 text-lg font-semibold">{p.name}</h3>
                <p className="text-sm text-gray-600">{p.description}</p>
                <div className="mt-3 flex items-center justify-between">
                  <div className="font-bold">${(p.price_cents/100).toFixed(2)}</div>
                  <Link href={`/product/${p.id}`} className="px-3 py-1 bg-amber-500 text-white rounded">View</Link>
                </div>
              </article>
            ))}
          </div>

          <section className="mt-10">
            <h2 className="text-2xl font-bold mb-4">Stories from the Oven</h2>
            <div className="space-y-4">
              <blockquote className="bg-white p-4 rounded shadow">
                <p className="italic">"Baked with love for Riley — small batches, big smiles."</p>
                <cite className="block mt-2 text-sm text-gray-500">— The Happy Batch</cite>
              </blockquote>

            </div>
          </section>
        </section>

        <aside className="bg-white p-4 rounded-lg shadow">
          <h2 className="font-bold text-lg">Quick Cart</h2>
          <p className="text-sm text-gray-500 mt-2">Use the product page to add to cart and checkout.</p>
        </aside>
      </main>

      <footer className="max-w-6xl mx-auto mt-12 text-center text-sm text-gray-500">
        <p>© {new Date().getFullYear()} The Happy Batch</p>
      </footer>
    </div>
  )
}
