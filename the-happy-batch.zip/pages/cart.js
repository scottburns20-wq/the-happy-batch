import { useEffect, useState } from 'react'
import { PRODUCTS } from '../lib/products'

export default function CartPage() {
  const [cart, setCart] = useState({})
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => {
    const c = JSON.parse(localStorage.getItem('cart') || '{}')
    setCart(c)
  }, [])

  useEffect(() => {
    const list = Object.entries(cart).map(([id, qty]) => ({ ...(PRODUCTS.find(p => p.id === id)), qty }))
    setItems(list)
  }, [cart])

  const subtotal = items.reduce((s, it) => s + it.price_cents * it.qty, 0)

  async function checkout(oneTime = true, useSubscription = false) {
    if (items.length === 0) { setMessage('Cart is empty'); return }
    setLoading(true)
    setMessage('')
    try {
      const res = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items, oneTime, useSubscription })
      })
      const data = await res.json()
      if (data.url) window.location.href = data.url
      else setMessage(data.error || 'Checkout failed')
    } catch (err) {
      setMessage('Network error')
    } finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen p-6 bg-gray-50">
      <main className="max-w-4xl mx-auto bg-white p-6 rounded shadow">
        <h1 className="text-2xl font-bold">Your Cart</h1>
        {items.length === 0 ? <p className="mt-4 text-gray-500">Cart is empty</p> : (
          <div className="mt-4 space-y-4">
            {items.map(it => (
              <div key={it.id} className="flex items-center justify-between">
                <div className="flex items-center">
                  <img src={it.image} className="w-16 h-16 object-cover rounded mr-3" />
                  <div>
                    <div className="font-medium">{it.name}</div>
                    <div className="text-sm text-gray-500">${(it.price_cents/100).toFixed(2)}</div>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="mr-4">x {it.qty}</div>
                </div>
              </div>
            ))}

            <div className="border-t pt-4 flex justify-between">
              <div className="font-bold">Subtotal</div>
              <div className="font-bold">${(subtotal/100).toFixed(2)}</div>
            </div>

            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button onClick={() => checkout(true, false)} disabled={loading} className="py-2 bg-indigo-600 text-white rounded">Pay one-time</button>
              <button onClick={() => checkout(false, true)} disabled={loading} className="py-2 border rounded">Subscribe (monthly)</button>
            </div>

            {message && <div className="mt-3 text-sm text-red-600">{message}</div>}
          </div>
        )}
      </main>
    </div>
  )
}
