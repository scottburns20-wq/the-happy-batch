import { useRouter } from 'next/router'
import { PRODUCTS } from '../../lib/products'
import { useState } from 'react'
import Link from 'next/link'

export default function ProductPage() {
  const router = useRouter()
  const { id } = router.query
  const product = PRODUCTS.find(p => p.id === id)
  const [qty, setQty] = useState(1)

  if (!product) return <div>Loading...</div>

  function addToCart() {
    const cart = JSON.parse(localStorage.getItem('cart') || '{}')
    cart[id] = (cart[id] || 0) + qty
    localStorage.setItem('cart', JSON.stringify(cart))
    router.push('/cart')
  }

  return (
    <div className="min-h-screen p-6 bg-gray-50">
      <main className="max-w-4xl mx-auto grid md:grid-cols-2 gap-6">
        <img src={product.image} className="w-full h-80 object-cover rounded" />
        <div>
          <h1 className="text-2xl font-bold">{product.name}</h1>
          <p className="mt-2 text-gray-600">{product.description}</p>
          <div className="mt-4 font-bold text-xl">${(product.price_cents/100).toFixed(2)}</div>

          <div className="mt-6">
            <label className="block text-sm">Quantity</label>
            <input type="number" value={qty} min={1} onChange={e => setQty(Number(e.target.value))} className="w-24 p-2 border rounded mt-1" />
          </div>

          <div className="mt-6 flex space-x-3">
            <button onClick={addToCart} className="px-4 py-2 bg-indigo-600 text-white rounded">Add to cart</button>
            <Link href="/cart" className="px-4 py-2 border rounded">View cart</Link>
          </div>
        </div>
      </main>
    </div>
  )
}
