import stripe from '../../lib/stripe'
import { PRODUCTS } from '../../lib/products'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end('Method Not Allowed')
  try {
    const { items, oneTime = true, useSubscription = false } = req.body

    for (const it of items) {
      const prod = PRODUCTS.find(p => p.id === it.id)
      if (!prod) return res.status(400).json({ error: 'Invalid product' })
      if (it.quantity > prod.inventory) return res.status(400).json({ error: `Not enough stock for ${prod.name}` })
    }

    const line_items = items.map(it => {
      const prod = PRODUCTS.find(p => p.id === it.id)
      const price = (useSubscription && prod.stripe_price_id_subscription && !oneTime)
        ? prod.stripe_price_id_subscription
        : prod.stripe_price_id_one_time
      return { price, quantity: it.quantity }
    })

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items,
      mode: useSubscription ? 'subscription' : 'payment',
      success_url: `${process.env.PUBLIC_BASE_URL || 'http://localhost:3000'}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.PUBLIC_BASE_URL || 'http://localhost:3000'}/cart`,
      allow_promotion_codes: true,
    })

    res.status(200).json({ url: session.url })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Unable to create session' })
  }
}
